<?php

// Displays the top ten movies based on the average rating






?>